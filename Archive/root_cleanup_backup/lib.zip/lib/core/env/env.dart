// Local optional secrets — do not commit real values (see .gitignore).
// Copy from env.dart.example. AI parsing is handled by the app backend, not client LLM keys.

abstract final class Env {
  /// Reserved for future client-side flags only; no third-party LLM keys in the Flutter app.
  static const String placeholder = '';
}
